from get_all_cars import *
from get_destination_by_name import *

def list_sahara_cars(destination_name: str) -> list:
    cars = []
    # code om de afstand op te zoeken in de tabel destinations
 
    # code om de cars te selecteren die de afstand in één keer kunnen overbruggen
 
    return cars
 
# code om de cars te selecteren die de afstand in één keer kunnen overbruggen
 
cars = list_sahara_cars('Cairo')